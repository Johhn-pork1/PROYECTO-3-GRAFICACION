package sistemasolar.raytracing;

import sistemasolar.geometria.Vec3;

/**
 * UNIDAD 5 + UNIDAD 3 - Un cuerpo del sistema solar para el raytracing: tamaño, textura y ÓRBITA.
 *
 * La órbita es la misma idea del proyecto 2D (Body.update): el cuerpo gira alrededor de su PADRE.
 *     posición(t) = posición del padre + punto de la órbita
 * El punto de la órbita, con el ángulo  a = fase + velOrbital * t :
 *     x = radioOrbita * cos(a)
 *     y = radioOrbita * sin(a) * cos(inclinacion)
 *     z = radioOrbita * sin(a) * sin(inclinacion)       (la inclinación saca la órbita del plano de la pantalla)
 * Con inclinacion = 0 la órbita es plana, como en el modo 2D. El Sol no tiene padre y radioOrbita = 0.
 */
public final class Planeta {
    public final String nombre;
    public final double radio;
    public final int colorBase;          // 0xRRGGBB, por si no hay textura
    public final Textura textura;        // puede ser null
    public final Planeta padre;          // alrededor de quién orbita (null = nadie, se queda en el origen)
    public final double radioOrbita, velOrbital, fase, inclinacion;
    public final boolean emisivo;        // true solo para el Sol

    public Planeta(String nombre, double radio, int colorBase, Textura textura,
                   Planeta padre, double radioOrbita, double velOrbital, double fase, double inclinacion,
                   boolean emisivo) {
        this.nombre = nombre; this.radio = radio; this.colorBase = colorBase; this.textura = textura;
        this.padre = padre; this.radioOrbita = radioOrbita; this.velOrbital = velOrbital;
        this.fase = fase; this.inclinacion = inclinacion; this.emisivo = emisivo;
    }

    /** Atajo para un planeta o luna normal (no emite luz). */
    public Planeta(String nombre, double radio, int colorBase, Textura textura,
                   Planeta padre, double radioOrbita, double velOrbital, double fase, double inclinacion) {
        this(nombre, radio, colorBase, textura, padre, radioOrbita, velOrbital, fase, inclinacion, false);
    }

    /** Posición del centro en el instante t (segundos). El padre se calcula primero (recursión). */
    public Vec3 posicion(double t) {
        Vec3 base = (padre == null) ? new Vec3(0, 0, 0) : padre.posicion(t);
        if (radioOrbita == 0) return base;
        double a = fase + velOrbital * t;
        double c = Math.cos(inclinacion), s = Math.sin(inclinacion);
        Vec3 local = new Vec3(radioOrbita * Math.cos(a),
                              radioOrbita * Math.sin(a) * c,
                              radioOrbita * Math.sin(a) * s);
        return base.add(local);
    }

    /** La esfera que el Trazador dibuja en el instante t. */
    public Esfera aEsfera(double t) {
        return new Esfera(posicion(t), radio, colorBase, textura, emisivo);
    }
}
