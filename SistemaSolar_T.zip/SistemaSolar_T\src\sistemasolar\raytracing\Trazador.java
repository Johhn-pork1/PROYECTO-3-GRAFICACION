package sistemasolar.raytracing;

import sistemasolar.geometria.Vec3;

import java.awt.image.BufferedImage;
import java.util.List;

/**
 * UNIDAD 5 (5.2, 5.4, 5.3 sombras) - Genera la imagen lanzando UN RAYO POR PIXEL desde la cámara (trazado inverso).
 *
 * Para cada pixel (px, py):
 *   1) Se arma el rayo: sale del ojo y pasa por ese pixel de una "pantalla" imaginaria.
 *   2) Se prueba contra todas las esferas y se queda la más cercana (menor t).   -> ray casting
 *   3) Se calcula el punto golpeado P y su normal N.
 *   4) RAYO DE SOMBRA: del punto P se lanza otro rayo hacia la luz. Si una esfera lo corta ANTES de llegar a la
 *      luz, P no recibe luz directa y queda en sombra.
 *   5) Color = colorSuperficie * (AMBIENTE + DIFUSA * max(0, N . L))   (solo se suma la parte difusa si no hay sombra).
 */
public final class Trazador {
    public static final double AMBIENTE = 0.12;     // luz mínima que siempre llega (para que la sombra no sea negra)
    public static final double DIFUSA = 0.88;

    public final List<Esfera> esferas;
    public final Vec3 luz;                          // posición de la fuente de luz
    public final Vec3 ojo;                          // posición de la cámara
    public final double distanciaPantalla;          // del ojo a la pantalla imaginaria (a lo largo de +z)
    /** Cuántos pixeles de cada esfera quedaron en sombra en el último cuadro (para decir QUIÉN recibe la sombra). */
    public final java.util.Map<Esfera, Integer> sombraPor = new java.util.IdentityHashMap<>();
    public int pixelesEnSombra;                     // en el último cuadro: puntos que miraban al Sol pero otro cuerpo les tapó la luz

    public Trazador(List<Esfera> esferas, Vec3 luz, Vec3 ojo, double distanciaPantalla) {
        this.esferas = esferas; this.luz = luz; this.ojo = ojo; this.distanciaPantalla = distanciaPantalla;
    }

    /** Rayo del ojo al pixel (px, py) de una imagen ancho x alto. La pantalla mide 2 de alto (y de -1 a 1). */
    public Rayo rayoDelPixel(int px, int py, int ancho, int alto) {
        double x = ((px + 0.5) / ancho * 2 - 1) * ((double) ancho / alto);   // izquierda -> derecha
        double y = 1 - (py + 0.5) / alto * 2;                                  // arriba -> abajo
        return new Rayo(ojo, new Vec3(x, y, distanciaPantalla));
    }

    /** Esfera más cercana golpeada por el rayo, o null. En golpe[0] deja el valor t. */
    public Esfera masCercana(Rayo r, double[] golpe) {
        Esfera mejor = null;
        double tMin = Double.MAX_VALUE;
        for (Esfera e : esferas) {
            double t = e.interseca(r);
            if (t > 0 && t < tMin) { tMin = t; mejor = e; }
        }
        golpe[0] = tMin;
        return mejor;
    }

    /** true si entre p y la luz hay una esfera que estorba (rayo de sombra). */
    public boolean enSombra(Vec3 p, Vec3 normal) {
        Vec3 haciaLuz = luz.sub(p);
        double distancia = haciaLuz.length();
        Vec3 origen = p.add(normal.mul(1e-4));          // se separa un pelito para no golpear la propia esfera
        Rayo sombra = new Rayo(origen, haciaLuz);
        for (Esfera e : esferas) {
            if (e.emisiva) continue;                    // el Sol no da sombra (la luz sale de él)
            double t = e.interseca(sombra);
            if (t > 0 && t < distancia) return true;
        }
        return false;
    }

    /** Color (0xRRGGBB) que ve el rayo. */
    public int colorDelRayo(Rayo r) {
        double[] golpe = new double[1];
        Esfera e = masCercana(r, golpe);
        if (e == null) return 0x080A18;                 // fondo: el mismo azul oscuro del panel
        Vec3 p = r.punto(golpe[0]);
        if (e.emisiva) return e.colorEn(p);             // el Sol se ve con su propio color, sin sombreado
        Vec3 n = e.normal(p);
        double difusa = Math.max(0, n.dot(luz.sub(p).normalized()));
        if (difusa > 0 && enSombra(p, n)) { difusa = 0; pixelesEnSombra++; sombraPor.merge(e, 1, Integer::sum); }
        double brillo = AMBIENTE + DIFUSA * difusa;
        int c = e.colorEn(p);
        int rr = (int) Math.min(255, ((c >> 16) & 255) * brillo);
        int gg = (int) Math.min(255, ((c >> 8) & 255) * brillo);
        int bb = (int) Math.min(255, (c & 255) * brillo);
        return (rr << 16) | (gg << 8) | bb;
    }

    /**
     * Imagen de una VENTANA del mundo, con el mismo sistema del panel (x a la derecha, y hacia arriba, z = 0 es el plano
     * de las órbitas). El ojo está en (cx, cy, -D) y mira hacia +z; "escala" son pixeles por unidad del mundo.
     * El rayo del pixel pasa por el punto del plano z = 0 que le toca: (dx, dy, 0) con dx = (px - ancho/2)/escala.
     */
    public BufferedImage renderizarVentana(int ancho, int alto, double escala) {
        BufferedImage img = new BufferedImage(ancho, alto, BufferedImage.TYPE_INT_RGB);
        pixelesEnSombra = 0;
        sombraPor.clear();
        for (int py = 0; py < alto; py++)
            for (int px = 0; px < ancho; px++) {
                double dx = (px + 0.5 - ancho / 2.0) / escala;
                double dy = -(py + 0.5 - alto / 2.0) / escala;
                img.setRGB(px, py, colorDelRayo(new Rayo(ojo, new Vec3(dx, dy, -ojo.z))));
            }
        return img;
    }

    public BufferedImage renderizar(int ancho, int alto) {
        BufferedImage img = new BufferedImage(ancho, alto, BufferedImage.TYPE_INT_RGB);
        pixelesEnSombra = 0;
        sombraPor.clear();
        for (int py = 0; py < alto; py++)
            for (int px = 0; px < ancho; px++)
                img.setRGB(px, py, colorDelRayo(rayoDelPixel(px, py, ancho, alto)));
        return img;
    }
}
