package sistemasolar.raytracing;

import sistemasolar.geometria.Vec3;

/**
 * UNIDAD 5 (5.2 y 5.5) - ESFERA: centro, radio y (opcional) textura.
 *
 * INTERSECCIÓN RAYO-ESFERA. Un punto P(t) = o + t*d está en la esfera si |P - c|^2 = r^2.
 * Con oc = o - c y |d| = 1 queda una ecuación de 2º grado en t:   t^2 + 2*b*t + k = 0
 *      b = oc . d          k = oc . oc - r^2           discriminante = b^2 - k
 *   discriminante < 0  -> el rayo pasa de largo (no toca)
 *   si no              -> t = -b - raiz(discriminante)   (la entrada, el punto más cercano)
 * Solo cuenta si t > EPS (delante del origen del rayo).
 */
public final class Esfera {
    public static final double EPS = 1e-6;

    public final Vec3 centro;
    public final double radio;
    public final int colorBase;          // 0xRRGGBB, se usa si no hay textura
    public final Textura textura;        // puede ser null
    public final boolean emisiva;        // true = produce luz (el Sol): no recibe sombra ni la proyecta
    public String nombre = "";            // para mostrar en pantalla qué cuerpo recibe sombra
    public double giro = 0;              // ángulo (rad) que la esfera ha girado sobre su eje vertical: hace rotar la textura

    public Esfera(Vec3 centro, double radio, int colorBase, Textura textura) {
        this(centro, radio, colorBase, textura, false);
    }

    public Esfera(Vec3 centro, double radio, int colorBase, Textura textura, boolean emisiva) {
        this.centro = centro; this.radio = radio; this.colorBase = colorBase; this.textura = textura;
        this.emisiva = emisiva;
    }

    /** Devuelve el parámetro t del primer golpe, o -1 si el rayo no toca la esfera. */
    public double interseca(Rayo r) {
        Vec3 oc = r.origen.sub(centro);
        double b = oc.dot(r.direccion);
        double k = oc.dot(oc) - radio * radio;
        double disc = b * b - k;
        if (disc < 0) return -1;
        double raiz = Math.sqrt(disc);
        double t = -b - raiz;
        if (t > EPS) return t;
        t = -b + raiz;                    // el origen está dentro de la esfera: vale la salida
        return t > EPS ? t : -1;
    }

    /** Normal (vector unitario que sale de la superficie) en el punto p. */
    public Vec3 normal(Vec3 p) { return p.sub(centro).mul(1.0 / radio); }

    /**
     * (u, v) de la textura en el punto p de la superficie (TEMA 5.5).
     *   u = longitud: el ángulo alrededor del eje vertical, de 0 a 1.
     *   v = latitud:  0 en el polo norte (arriba), 1 en el polo sur.
     */
    public double[] uv(Vec3 p) {
        Vec3 n = normal(p);
        double u = 0.5 + (Math.atan2(n.z, n.x) - giro) / (2 * Math.PI);
        u = u - Math.floor(u);                       // u siempre entre 0 y 1 (la textura se repite al girar)
        double v = 0.5 - Math.asin(Math.max(-1, Math.min(1, n.y))) / Math.PI;
        return new double[]{u, v};
    }

    /** Color de la superficie en p: el de la textura si hay, si no el color base. */
    public int colorEn(Vec3 p) {
        if (textura == null) return colorBase;
        double[] uv = uv(p);
        return textura.color(uv[0], uv[1]);
    }
}
