package sistemasolar.escena;

import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JToggleButton;
import javax.swing.SwingUtilities;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;

/** Punto de entrada: abre la ventana con el sistema solar (clic derecho > Run File, o F6 si es la clase principal). */
public class SolarSystem {
    /** Botones de la ventana (para poder probarlos sin abrir la ventana). */
    public static JToggleButton botonSin, botonCon;

    /**
     * Arma el contenido de la ventana: arriba dos botones, abajo el panel del sistema solar.
     *   [Sin raytracing]  la vista normal de las Unidades 3 y 4 (Java2D o algoritmos propios).
     *   [Con raytracing]  la misma escena con un rayo por pixel, texturas y sombras (Unidad 5).
     * La tecla K hace lo mismo y mantiene los botones al día.
     */
    public static JPanel crearContenido(SolarSystemPanel panel) {
        botonSin = new JToggleButton("Sin raytracing", true);
        botonCon = new JToggleButton("Con raytracing");
        ButtonGroup grupo = new ButtonGroup();
        grupo.add(botonSin);
        grupo.add(botonCon);
        botonSin.addActionListener(e -> { panel.setModoRayos(false); panel.requestFocusInWindow(); });
        botonCon.addActionListener(e -> { panel.setModoRayos(true); panel.requestFocusInWindow(); });
        // si se cambia con la tecla K, los botones lo reflejan
        panel.setAlCambiarModo(rayos -> (rayos ? botonCon : botonSin).setSelected(true));

        JPanel barra = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 6));
        barra.setBackground(new Color(30, 34, 52));
        JLabel etiqueta = new JLabel("Vista:");
        etiqueta.setForeground(new Color(215, 220, 235));
        barra.add(etiqueta);
        barra.add(botonSin);
        barra.add(botonCon);
        JPanel contenido = new JPanel(new BorderLayout());
        contenido.add(barra, BorderLayout.NORTH);
        contenido.add(panel, BorderLayout.CENTER);
        return contenido;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame f = new JFrame("Sistema solar - Graficación computacional");
            f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            SolarSystemPanel panel = new SolarSystemPanel();
            f.add(crearContenido(panel));
            f.pack();
            f.setLocationRelativeTo(null);
            f.setVisible(true);
            panel.requestFocusInWindow();
        });
    }
}
