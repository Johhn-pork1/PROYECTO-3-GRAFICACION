package sistemasolar.raytracing;

import java.util.List;

/**
 * ===== ESTE ES TU ARCHIVO =====  Aquí agregas tus planetas, cada uno con SU TEXTURA y SU ÓRBITA.
 * No necesitas tocar ninguna otra clase.
 *
 * Pasos para cada planeta nuevo:
 *   1) Dibuja su textura con letras (un método como marte() de abajo).
 *   2) Crea el Planeta: nombre, radio, color, textura, padre, radioOrbita, velOrbital, fase, inclinacion.
 *   3) Agrégalo a la lista:  lista.add(miPlaneta);
 * Recuerda: si tu planeta tiene una luna, la luna lleva como PADRE a tu planeta (como la Luna y la Tierra).
 */
public final class MisPlanetas {
    private MisPlanetas() {}

    /** EJEMPLO: Marte, 12 columnas x 6 filas. R = roca roja, O = roca oscura, H = hielo del polo. */
    public static Textura marte() {
        return Textura.desdeTexto(new String[]{
                "HHHHHHHHHHHH",
                "RRORRRRRORRR",
                "RORRRROORRRR",
                "RRRRORRRRRRO",
                "RRRORRRRRORR",
                "HHHHHHHHHHHH"},
                new char[]{'R', 'O', 'H'}, new int[]{0xD2694A, 0x8E3F2C, 0xF0E6E0});
    }

    // =====================================================================================
    // [Parte C] TEXTURAS DE LOS PLANETAS NUEVOS (16 columnas x 8 filas cada una).
    // Cada letra es un pixel; la fila de arriba es el polo norte y la de abajo el polo sur.
    // =====================================================================================

    /** Mercurio: roca gris llena de cráteres. G = gris, O = cráter oscuro, C = polvo claro. */
    public static Textura mercurio() {
        return Textura.desdeTexto(new String[]{
                "GGCGGGGGCGGGGCGG",
                "GOGGGCGGGGOOGGGG",
                "GGGOOGGGCGGGGGOG",
                "CGGOOGGGGGGOGGGG",
                "GGGGGGCGGGGGGCGG",
                "GOGGGGGGOOGGGGGO",
                "GGGCGGGGOOGGCGGG",
                "GGGGGOGGGGGGGGGG"},
                new char[]{'G', 'O', 'C'}, new int[]{0xA59D94, 0x6B645E, 0xCFC8BE});
    }

    /** Venus: nubes espesas amarillentas en franjas suaves. A = amarillo, N = nube clara, M = marrón. */
    public static Textura venus() {
        return Textura.desdeTexto(new String[]{
                "NNNNNNNNNNNNNNNN",
                "AAANNNAAAAANNNAA",
                "AAAAAAAMMAAAAAAA",
                "NNAAAAAAAAAAANNN",
                "AAAAMMMAAAAAAAAA",
                "AAANNNNNAAAAMMAA",
                "MAAAAAAAAANNNAAA",
                "NNNNNNNNNNNNNNNN"},
                new char[]{'A', 'N', 'M'}, new int[]{0xE3C27E, 0xF4E2B8, 0xB88A4E});
    }

    /** Júpiter: bandas de nubes y la Gran Mancha Roja. C = crema, B = banda café, N = naranja, R = mancha roja. */
    public static Textura jupiter() {
        return Textura.desdeTexto(new String[]{
                "BBBBBBBBBBBBBBBB",
                "CCCCCCCCCCCCCCCC",
                "NNNNNNNNNNNNNNNN",
                "CCCCCCCCCCCCCCCC",
                "BBBBBBBBBBBBBBBB",
                "CCCCCCCCCRRRCCCC",
                "NNNNNNNNRRRRNNNN",
                "BBBBBBBBBBBBBBBB"},
                new char[]{'C', 'B', 'N', 'R'}, new int[]{0xEADBC2, 0x9C6B48, 0xD49A64, 0xB5442C});
    }

    /** Saturno: bandas suaves color arena. A = arena, D = dorado, O = ocre. */
    public static Textura saturno() {
        return Textura.desdeTexto(new String[]{
                "OOOOOOOOOOOOOOOO",
                "AAAAAAAAAAAAAAAA",
                "DDDDDDDDDDDDDDDD",
                "AAAAAAAAAAAAAAAA",
                "AAAADDDDAAAAAAAA",
                "DDDDDDDDDDDDDDDD",
                "AAAAAAAAAAAAAAAA",
                "OOOOOOOOOOOOOOOO"},
                new char[]{'A', 'D', 'O'}, new int[]{0xE6D3A3, 0xCDA866, 0xA88653});
    }

    /** Urano: gigante de hielo verde-azulado, casi liso. U = cian, C = cian claro, P = polo pálido. */
    public static Textura urano() {
        return Textura.desdeTexto(new String[]{
                "PPPPPPPPPPPPPPPP",
                "CCCCCCCCCCCCCCCC",
                "UUUUUUUUUUUUUUUU",
                "UUUUUUCCUUUUUUUU",
                "UUUUUUUUUUUUUCCU",
                "UUUUUUUUUUUUUUUU",
                "CCCCCCCCCCCCCCCC",
                "PPPPPPPPPPPPPPPP"},
                new char[]{'U', 'C', 'P'}, new int[]{0x7FCBD6, 0xA6E0E6, 0xD6F2F2});
    }

    /** Neptuno: azul intenso con la Gran Mancha Oscura y nubes blancas. A = azul, O = azul oscuro, B = nube blanca. */
    public static Textura neptuno() {
        return Textura.desdeTexto(new String[]{
                "AAAAAAAAAAAAAAAA",
                "AAAABBBAAAAAAAAA",
                "AAAAAAAAAAAAAAAA",
                "AAAAAAOOOAAAABBA",
                "AAAAAOOOOAAAAAAA",
                "ABBAAAAAAAAAAAAA",
                "AAAAAAAAAABBBAAA",
                "OOOOOOOOOOOOOOOO"},
                new char[]{'A', 'O', 'B'}, new int[]{0x3F63D8, 0x23367E, 0xDCE6FA});
    }


    /**
     * Textura (imagen) de un cuerpo de la ventana principal para la vista «Con raytracing».
     * Recibe el nombre del cuerpo (el mismo que le pusiste en SolarSystemPanel) y devuelve su textura,
     * o null si no tiene (entonces se ve de un solo color). La Tierra y la Luna ya traen la suya.
     * Agrega un caso por cada planeta nuevo al que le dibujes textura.
     */
    public static Textura texturaPara(String nombreCuerpo) {
        switch (nombreCuerpo) {
            case "Marte": return marte();                       // EJEMPLO
            // [Parte C] el nombre del case es IGUAL al que tiene el planeta en SolarSystemPanel (con acento)
            case "Mercurio": return mercurio();
            case "Venus":    return venus();
            case "Júpiter":  return jupiter();
            case "Saturno":  return saturno();
            case "Urano":    return urano();
            case "Neptuno":  return neptuno();
            default: return null;
        }
    }

    // PASO 1: dibuja la textura de tu planeta (mínimo 8 x 4). Cada letra es un color de la leyenda.
    // public static Textura miPlaneta() {
    //     return Textura.desdeTexto(new String[]{
    //             "........",
    //             "........",
    //             "........",
    //             "........"},
    //             new char[]{'A', 'B'}, new int[]{0x000000, 0xFFFFFF});
    // }

    /**
     * Se llama una sola vez al armar la escena. Recibe la lista, el Sol y la Tierra (por si quieres usarlos de padre).
     */
    public static void agregar(List<Planeta> lista, Planeta sol, Planeta tierra) {
        // EJEMPLO: Marte orbita al Sol, más lejos que la Tierra, más lento y con la órbita inclinada.
        //                 nombre   radio  color     textura   padre  radioOrbita velOrbital fase inclinación
        Planeta marte = new Planeta("Marte", 0.65, 0xD2694A, marte(), sol, 5.0, 0.45, 2.0, Math.toRadians(14));
        lista.add(marte);

        // PASO 2: agrega TU planeta con su textura y su órbita (alrededor del Sol).
        // Planeta miPlaneta = new Planeta("Mi planeta", 0.7, 0x808080, miPlaneta(), sol, 6.0, 0.3, 0.5, Math.toRadians(10));
        // lista.add(miPlaneta);

        // PASO 3: agrega una LUNA a tu planeta (el padre es tu planeta, no el Sol).
        // lista.add(new Planeta("Mi luna", 0.2, 0xBBBBBB, null, miPlaneta, 1.4, 2.5, 0, 0));
    }
}
