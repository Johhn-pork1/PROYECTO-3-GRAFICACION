package sistemasolar.raytracing;

/**
 * UNIDAD 5 (5.5) - TEXTURA: una imagen chica (una tabla de colores) que se "envuelve" en la esfera.
 * Se consulta con (u, v), dos números entre 0 y 1:  u = a lo ancho (0 izquierda, 1 derecha),
 * v = a lo alto (0 arriba, 1 abajo). Se usa el vecino más cercano: u*ancho y v*alto, redondeado hacia abajo.
 * Las dos imágenes se generan con texto, así que no hace falta ningún archivo externo.
 */
public final class Textura {
    private final int[][] pix;     // pix[fila][columna] en 0xRRGGBB
    private final int ancho, alto;

    public Textura(int[][] pix) { this.pix = pix; this.alto = pix.length; this.ancho = pix[0].length; }

    /** Color (0xRRGGBB) en la coordenada (u, v). */
    public int color(double u, double v) {
        int col = Math.min(ancho - 1, Math.max(0, (int) Math.floor(u * ancho)));
        int fil = Math.min(alto - 1, Math.max(0, (int) Math.floor(v * alto)));
        return pix[fil][col];
    }

    /** Crea una textura desde filas de texto: cada letra es un color (mapa de la leyenda). */
    public static Textura desdeTexto(String[] filas, char[] letras, int[] colores) {
        int[][] p = new int[filas.length][filas[0].length()];
        for (int f = 0; f < filas.length; f++)
            for (int c = 0; c < filas[f].length(); c++) {
                char ch = filas[f].charAt(c);
                int color = colores[0];
                for (int i = 0; i < letras.length; i++) if (letras[i] == ch) color = colores[i];
                p[f][c] = color;
            }
        return new Textura(p);
    }

    /** Tierra: 16 x 8. A = agua, T = tierra, H = hielo. */
    public static Textura tierra() {
        return desdeTexto(new String[]{
                "HHHHHHHHHHHHHHHH",
                "AATTAAAAAATTTAAA",
                "ATTTTAAAATTTTTAA",
                "AATTTAAATTTTTTTA",
                "AAATAAAATTTTAATA",
                "AAAAAAAAATTAAAAA",
                "AAATTAAAAAAAAAAA",
                "HHHHHHHHHHHHHHHH"},
                new char[]{'A', 'T', 'H'}, new int[]{0x2E6FC9, 0x4E9A4A, 0xF2F5F8});
    }

    /** Luna: 8 x 4. G = gris claro, O = gris oscuro (cráteres). */
    public static Textura luna() {
        return desdeTexto(new String[]{
                "GGOGGGOG",
                "GOGGGOGG",
                "GGGOGGGO",
                "OGGGOGGG"},
                new char[]{'G', 'O'}, new int[]{0xC8C8CD, 0x7C7C84});
    }
}
