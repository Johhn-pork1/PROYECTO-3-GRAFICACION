package sistemasolar.raytracing;

import sistemasolar.geometria.Vec3;

/**
 * UNIDAD 5 (5.2 y 5.4) - Un RAYO: un punto de origen y una dirección.
 * Punto del rayo en el parámetro t:  P(t) = origen + t * direccion   (t >= 0 es "hacia adelante").
 * Es la misma idea de vector (2.1) y producto punto (2.2) de la Unidad 2, ahora en 3D.
 */
public final class Rayo {
    public final Vec3 origen;
    public final Vec3 direccion;      // siempre de longitud 1

    public Rayo(Vec3 origen, Vec3 direccion) {
        this.origen = origen;
        this.direccion = direccion.normalized();
    }

    public Vec3 punto(double t) { return origen.add(direccion.mul(t)); }
}
