package sistemasolar.raytracing;

import sistemasolar.geometria.Vec3;

import java.util.ArrayList;
import java.util.List;

/**
 * Arma la escena: Sol (luz), Tierra, Luna y los planetas de MisPlanetas. Para un instante t crea las esferas
 * en su posición de ese momento y las entrega al Trazador. La luz está en el Sol, en el origen.
 */
public final class EscenaRayos {
    private final List<Planeta> planetas = new ArrayList<>();

    public EscenaRayos() {
        Planeta sol    = new Planeta("Sol", 1.3, 0xFFC43C, null, null, 0, 0, 0, 0, true);
        Planeta tierra = new Planeta("Tierra", 0.9, 0x2E6FC9, Textura.tierra(), sol, 3.2, 0.8, 0, 0);
        Planeta luna   = new Planeta("Luna", 0.28, 0xC8C8CD, Textura.luna(), tierra, 1.5, 3.2, 1.0, Math.toRadians(25));
        planetas.add(sol); planetas.add(tierra); planetas.add(luna);
        MisPlanetas.agregar(planetas, sol, tierra);      // <- aquí entran los planetas de MisPlanetas
    }

    public List<Planeta> planetas() { return planetas; }

    /** El Trazador de la escena en el instante t. La cámara está lejos, en -z, mirando hacia +z. */
    public Trazador en(double t) {
        List<Esfera> esferas = new ArrayList<>();
        for (Planeta p : planetas) esferas.add(p.aEsfera(t));
        return new Trazador(esferas, new Vec3(0, 0, 0), new Vec3(0, 0, -22), 3.0);
    }
}
