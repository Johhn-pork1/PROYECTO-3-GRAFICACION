package sistemasolar.raytracing;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;

/**
 * UNIDAD 5 - Ventana aparte. Ejecuta esta clase (main). Se calcula cada cuadro con raytracing, así que es lento:
 * por eso la imagen es chica (640 x 400). ESPACIO = pausa.   Con  -Dcuadros=1  solo imprime y termina (pruebas).
 */
public final class VistaRayos {
    static final int ANCHO = 640, ALTO = 400;
    private static volatile BufferedImage cuadro = new BufferedImage(ANCHO, ALTO, BufferedImage.TYPE_INT_RGB);
    private static volatile boolean pausa = false;

    public static void main(String[] args) {
        EscenaRayos escena = new EscenaRayos();
        JPanel panel = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(cuadro, 0, 0, getWidth(), getHeight(), null);
                g.setColor(Color.LIGHT_GRAY);
                g.drawString("[ESPACIO] pausa", 10, getHeight() - 10);
            }
        };
        panel.setPreferredSize(new Dimension(ANCHO, ALTO));
        panel.setFocusable(true);
        panel.addKeyListener(new KeyAdapter() {
            @Override public void keyPressed(KeyEvent e) { if (e.getKeyCode() == KeyEvent.VK_SPACE) pausa = !pausa; }
        });
        JFrame f = new JFrame("Unidad 5 - Raytracing: sistema solar");
        f.add(panel);
        f.pack();
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setVisible(true);

        Thread hilo = new Thread(() -> {
            double t = 0;
            while (true) {
                if (!pausa) t += 0.08;
                cuadro = escena.en(t).renderizar(ANCHO, ALTO);
                SwingUtilities.invokeLater(panel::repaint);
            }
        });
        hilo.setDaemon(true);
        hilo.start();
    }
}
